#pragma once
#include <string>
namespace edutrack { namespace domain {
struct Admin {
    std::string id;
    std::string name;
};
}} // namespace
