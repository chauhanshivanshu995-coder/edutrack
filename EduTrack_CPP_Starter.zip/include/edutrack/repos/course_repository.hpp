#pragma once
#include <vector>
#include <unordered_map>
#include "../domain/course.hpp"
namespace edutrack { namespace repos {
class CourseRepository {
public:
    void addCourse(const edutrack::domain::Course& c) { courses[c.id] = c; }
    std::vector<edutrack::domain::Course> findEligibleCourses(const std::string&) const {
        std::vector<edutrack::domain::Course> out;
        out.reserve(courses.size());
        for (const auto& kv : courses) out.push_back(kv.second);
        return out;
    }
private:
    std::unordered_map<std::string, edutrack::domain::Course> courses;
};
}} // namespace
