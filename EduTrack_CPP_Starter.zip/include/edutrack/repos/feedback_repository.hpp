#pragma once
#include <vector>
#include <string>
#include <unordered_map>
#include "../domain/feedback.hpp"
namespace edutrack { namespace repos {
class FeedbackRepository {
public:
    void save(const edutrack::domain::Feedback& f) { store[f.id] = f; }
    std::vector<edutrack::domain::Feedback> findByCourse(const std::string& courseId) const {
        std::vector<edutrack::domain::Feedback> out;
        for (const auto& kv : store) if (kv.second.courseId == courseId) out.push_back(kv.second);
        return out;
    }
    std::vector<edutrack::domain::Feedback> findAll() const {
        std::vector<edutrack::domain::Feedback> out;
        out.reserve(store.size());
        for (const auto& kv : store) out.push_back(kv.second);
        return out;
    }
private:
    std::unordered_map<std::string, edutrack::domain::Feedback> store;
};
}} // namespace
