#include "../include/edutrack/services/report_service.hpp"
#include <cmath>
using namespace edutrack::services;
using edutrack::domain::Feedback;
using edutrack::domain::Report;
Report ReportService::buildCourseReport(const std::vector<Feedback>& feedbacks) const {
    Report r;
    if (feedbacks.empty()) return r;
    r.courseId = feedbacks.front().courseId;
    double sum = 0.0;
    for (const auto& f : feedbacks) {
        sum += f.rating;
        if (!f.comment.empty()) r.comments.push_back(f.comment);
    }
    r.totalResponses = static_cast<int>(feedbacks.size());
    r.averageRating = r.totalResponses ? std::round((sum / r.totalResponses) * 100.0) / 100.0 : 0.0;
    return r;
}
