#include "../include/edutrack/services/feedback_service.hpp"
#include <stdexcept>
#include <chrono>
using namespace edutrack::services;
using edutrack::domain::Feedback;
using edutrack::domain::Report;
std::string FeedbackService::generateId() const {
    static long counter = 0;
    return "fb_" + std::to_string(++counter);
}
Feedback FeedbackService::submitFeedback(const std::string& studentId, const std::string& courseId, int rating, const std::string& comment) {
    Feedback f;
    f.id = generateId();
    f.courseId = courseId;
    f.studentId = studentId;
    f.rating = rating;
    f.comment = comment;
    f.timestamp = std::chrono::system_clock::now();
    if (!f.isValidRating()) throw std::invalid_argument("Rating must be an integer in [1..5].");
    fbRepo_.save(f);
    return f;
}
Report FeedbackService::getFacultyView(const std::string& courseId) const {
    auto fbs = fbRepo_.findByCourse(courseId);
    return repSvc_.buildCourseReport(fbs);
}
std::vector<Feedback> FeedbackService::getAdminAll() const { return fbRepo_.findAll(); }
