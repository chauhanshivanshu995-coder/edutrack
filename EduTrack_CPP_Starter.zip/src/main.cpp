#include <iostream>
#include <string>
#include <unordered_map>
#include "../include/edutrack/services/auth_service.hpp"
#include "../include/edutrack/services/feedback_service.hpp"
#include "../include/edutrack/services/report_service.hpp"
#include "../include/edutrack/repos/feedback_repository.hpp"
#include "../include/edutrack/repos/course_repository.hpp"
void seedCourses(edutrack::repos::CourseRepository& repo);
int main() {
    using namespace edutrack;
    std::unordered_map<std::string,std::string> users{{"s1","STUDENT"},{"s2","STUDENT"},{"f1","FACULTY"},{"admin","ADMIN"}};
    services::AuthService auth(users);
    repos::FeedbackRepository fbRepo;
    repos::CourseRepository cRepo;
    seedCourses(cRepo);
    services::ReportService repSvc;
    services::FeedbackService fbSvc(fbRepo, cRepo, repSvc);
    std::cout << "Welcome to EduTrack CLI (C++)\n\n";
    std::string uid, role;
    std::cout << "Enter user id [s1/s2/f1/admin]: "; std::getline(std::cin, uid);
    std::cout << "Enter role [STUDENT/FACULTY/ADMIN]: "; std::getline(std::cin, role);
    if (!auth.login(uid, role)) { std::cout << "Login failed.\n"; return 0; }
    if (role == "STUDENT") {
        auto courses = cRepo.findEligibleCourses(uid);
        std::cout << "Eligible courses:\n";
        for (const auto& c : courses) std::cout << "- " << c.id << " " << c.code << ": " << c.title << "\n";
        std::string courseId, ratingStr, comment;
        std::cout << "Course ID to submit feedback for: "; std::getline(std::cin, courseId);
        std::cout << "Rating [1..5]: "; std::getline(std::cin, ratingStr);
        std::cout << "Comment: "; std::getline(std::cin, comment);
        try {
            int rating = std::stoi(ratingStr);
            auto f = fbSvc.submitFeedback(uid, courseId, rating, comment);
            std::cout << "Submitted: " << f.id << "\n";
        } catch (const std::exception& e) { std::cout << "Error: " << e.what() << "\n"; }
    } else if (role == "FACULTY") {
        std::string courseId; std::cout << "Enter your course ID to view report: "; std::getline(std::cin, courseId);
        auto report = fbSvc.getFacultyView(courseId);
        std::cout << "Report for " << courseId << ": avg=" << report.averageRating << ", total=" << report.totalResponses << "\n";
        std::cout << "Comments (anonymous):\n"; for (const auto& c : report.comments) std::cout << "- " << c << "\n";
    } else if (role == "ADMIN") {
        auto all = fbSvc.getAdminAll();
        std::cout << "All feedback entries (" << all.size() << "):\n";
        for (const auto& f : all) std::cout << "#" << f.id << " course=" << f.courseId << " rating=" << f.rating << " comment=\"" << f.comment << "\" studentId=" << f.studentId << "\n";
    } else { std::cout << "Unknown role.\n"; }
    return 0;
}
