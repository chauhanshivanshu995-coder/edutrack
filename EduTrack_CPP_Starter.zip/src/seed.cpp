#include "../include/edutrack/repos/course_repository.hpp"
#include "../include/edutrack/domain/course.hpp"
using edutrack::repos::CourseRepository;
using edutrack::domain::Course;
void seedCourses(CourseRepository& repo) {
    repo.addCourse(Course{"c1","CS101","Intro to CS"});
    repo.addCourse(Course{"c2","CS202","Data Structures"});
}
